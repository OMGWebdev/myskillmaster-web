#!/bin/bash
sudo service nginx stop