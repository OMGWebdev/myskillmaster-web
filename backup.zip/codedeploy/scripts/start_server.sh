#!/bin/bash
sudo service nginx restart