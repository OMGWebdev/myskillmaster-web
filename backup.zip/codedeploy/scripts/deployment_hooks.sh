#!/bin/bash
cd /var/www/web
npm rebuild
npm run build
npm run generate