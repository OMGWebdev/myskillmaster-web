import State from '@/utils/rawStates/State'

const rawListingEnrollmentForm = () => {
  return State({
    search: ''
  })
}

export default rawListingEnrollmentForm
