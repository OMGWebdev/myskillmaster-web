import State from '@/utils/rawStates/State'

const rawPaymentMethodForm = () => {
  return State({
    source: '',
    name: ''
  })
}

export default rawPaymentMethodForm
