import State from '@/utils/rawStates/State'

const rawListingPaymentMethodForm = () => {
  return State({})
}

export default rawListingPaymentMethodForm
