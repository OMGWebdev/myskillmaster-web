import State from '@/utils/rawStates/State'

const rawLogoutForm = () => {
  return State({})
}

export default rawLogoutForm
