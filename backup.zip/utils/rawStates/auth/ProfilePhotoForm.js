import State from '@/utils/rawStates/State'

const rawProfilePhotoForm = () => {
  return State({
    avatar: null
  })
}

export default rawProfilePhotoForm
