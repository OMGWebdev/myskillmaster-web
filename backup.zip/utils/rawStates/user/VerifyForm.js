import State from '@/utils/rawStates/State'

const rawVerifyForm = () => {
  return State({
    token: ''
  })
}

export default rawVerifyForm
