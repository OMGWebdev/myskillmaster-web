import State from '@/utils/rawStates/State'

const rawInterestForm = () => {
  return State({
    category_ids: []
  })
}

export default rawInterestForm
