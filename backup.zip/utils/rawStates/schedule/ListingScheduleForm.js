import State from '@/utils/rawStates/State'

const rawListingScheduleForm = () => {
  return State({
    search: ''
  })
}

export default rawListingScheduleForm
