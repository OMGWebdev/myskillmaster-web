import State from '@/utils/rawStates/State'

const rawTermsForm = () => {
  return State({
    content: ''
  })
}

export default rawTermsForm
