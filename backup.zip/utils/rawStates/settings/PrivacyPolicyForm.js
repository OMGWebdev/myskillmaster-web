import State from '@/utils/rawStates/State'

const rawPrivacyPolicyForm = () => {
  return State({
    content: ''
  })
}

export default rawPrivacyPolicyForm
