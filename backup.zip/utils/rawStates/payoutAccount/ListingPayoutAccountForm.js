import State from '@/utils/rawStates/State'

const rawListingPayoutAccountForm = () => {
  return State({})
}

export default rawListingPayoutAccountForm
