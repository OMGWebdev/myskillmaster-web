import State from '@/utils/rawStates/State'

const rawListingLessonForm = () => {
  return State({
    search: ''
  })
}

export default rawListingLessonForm
