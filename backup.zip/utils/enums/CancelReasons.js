const CANCELLATION_REASONS = [
  {
    text: 'Work',
    value: 'work'
  },
  {
    text: 'Sickness',
    value: 'sickness'
  },
  {
    text: 'Personal Reasons',
    value: 'personal_reasons'
  },
  {
    text: 'Date Unavailability',
    value: 'date_unavailability'
  },
  {
    text: 'Others',
    value: 'others'
  }
]
export default CANCELLATION_REASONS
