const LESSON = 'lesson'
const SCHEDULE = 'schedule'
const ENROLLMENT = 'enrollment'
const TYPES = [LESSON, SCHEDULE, ENROLLMENT]

export { LESSON, SCHEDULE, ENROLLMENT, TYPES }
