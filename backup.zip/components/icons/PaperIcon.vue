<template>
  <svg
    width="18"
    height="14"
    viewBox="0 0 18 14"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="v-icon--custom"
  >
    <path
      d="M4.2 2.63333V7.96667L1 13.3H14.8667C16.0453 13.3 17 12.3453 17 11.1667V2.63333C17 1.45467 16.0453 0.5 14.8667 0.5H6.33333C5.15467 0.5 4.2 1.45467 4.2 2.63333Z"
      stroke="#000000"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.40039 3.7002H13.8004"
      stroke="#000000"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.40039 6.8999H13.8004"
      stroke="#000000"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.40039 10.1001H10.6004"
      stroke="#000000"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
<script>
/**
 * ==================================================================================
 * Paper Icon
 * ==================================================================================
 **/

export default {}
</script>
