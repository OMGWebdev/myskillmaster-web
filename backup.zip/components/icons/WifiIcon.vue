<template>
  <svg
    width="17"
    height="19"
    viewBox="0 0 17 19"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="v-icon--custom"
  >
    <path
      d="M14.0065 17.6666C15.3159 15.1134 15.9992 12.2853 16 9.41593C15.9992 6.54652 15.3159 3.71844 14.0065 1.16522"
      stroke="#839A9C"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M9.62549 15.5919C10.6255 13.6869 11.1477 11.5675 11.147 9.41595C11.1477 7.26445 10.6255 5.145 9.62549 3.24005"
      stroke="#839A9C"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M5.23779 13.5146C5.93137 12.2599 6.29462 10.8495 6.2934 9.41592C6.29462 7.98231 5.93137 6.57193 5.23779 5.31726"
      stroke="#839A9C"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M0.833252 11.4265C1.22986 10.831 1.44098 10.1314 1.43992 9.41596C1.44098 8.70054 1.22986 8.00088 0.833252 7.40546"
      stroke="#839A9C"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
<script>
/**
 * ==================================================================================
 * Wifi Icon
 * ==================================================================================
 **/

export default {}
</script>
