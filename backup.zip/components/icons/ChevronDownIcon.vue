<template>
  <svg
    width="15"
    height="8"
    viewBox="0 0 15 8"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="v-icon--custom"
  >
    <path
      d="M1.74719 1L7.74719 7L13.7472 0.999999"
      stroke="#0A2127"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
<script>
/**
 * ==================================================================================
 * Chevron Down Icon
 * ==================================================================================
 **/

export default {}
</script>
