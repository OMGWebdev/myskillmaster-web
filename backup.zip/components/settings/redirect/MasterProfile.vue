<template>
  <div class="master-profile menu">
    <div class="mb-4">
      <hr class="mb-3">

      <NuxtLink
        :to="{
          name: 'settings-master-profile',
        }"
        class="mx-4"
      >
        Master Profile
      </NuxtLink>

      <hr class="mt-3">
    </div>
  </div>
</template>
<script>
/**
 * ==================================================================================
 * Master Profile
 * ==================================================================================
 **/

export default {}
</script>
<style scoped lang="scss">
.master-profile {
}
</style>
