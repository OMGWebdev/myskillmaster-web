<template>
  <v-col
    cols="12"
    md="auto"
    class="nav-with-title d-flex flex-row align-center"
  >
    <slot />
  </v-col>
</template>
<script>
/**
 * ==================================================================================
 * Navigation toggle
 * ==================================================================================
 **/

export default {}
</script>
<style scoped lang="scss">
.nav-with-title {
  //
}
</style>
