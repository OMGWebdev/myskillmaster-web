const env = {
  appName: process.env.appName,
  apiUrl: process.env.apiUrl,
  baseUrl: process.env.baseUrl,
  googlePlacesApiKey: process.env.googlePlacesApiKey,
  stripePublishableKey: process.env.stripePublishableKey
}
export default env
