import Vue from 'vue'
import VueTelInputVuetify from 'vue-tel-input-vuetify/lib/vue-tel-input-vuetify'

Vue.component('VueTelInputVuetify', VueTelInputVuetify)
