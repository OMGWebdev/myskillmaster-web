import Vue from 'vue'
import DatePicker from 'vue2-datepicker'

Vue.component('DatePicker', DatePicker)
