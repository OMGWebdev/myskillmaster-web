import { required } from 'vuelidate/lib/validators'

export const subscribeForm = {
  name: {
    required
  },
  source: {},
  plan: {}
}
