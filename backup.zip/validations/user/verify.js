import { required } from 'vuelidate/lib/validators'

export const verifyForm = {
  token: {
    required
  }
}
