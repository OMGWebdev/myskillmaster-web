import { required } from 'vuelidate/lib/validators'

export const interestsForm = {
  category_ids: {
    required
  }
}
