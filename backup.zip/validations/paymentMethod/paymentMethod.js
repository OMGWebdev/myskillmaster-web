import { required } from 'vuelidate/lib/validators'

export const paymentMethodForm = {
  name: {
    required
  },
  source: {}
}
