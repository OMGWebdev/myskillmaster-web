import { required } from 'vuelidate/lib/validators'

export const lessonEnrollSchedule = {
  schedule_id: {
    required
  }
}
