import { required } from 'vuelidate/lib/validators'

export const lessonEnrollPayment = {
  payment_method_id: {
    required
  }
}
