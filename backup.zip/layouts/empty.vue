<template>
  <Basic class="empty-layout" />
</template>
<script>
/**
 * ==================================================================================
 * Empty Layout
 * ==================================================================================
 **/

import Basic from '@/components/layouts/Basic'

export default {
  name: 'EmptyLayout',
  components: {
    Basic
  }
}
</script>
<style scoped lang="scss">
.empty-layout {
  //
}
</style>
