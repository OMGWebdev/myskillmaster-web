import Model from '@/models/Model'

export default class Location extends Model {
  resource() {
    return 'places'
  }
}
