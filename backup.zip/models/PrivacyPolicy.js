import Model from '@/models/Model'

export default class PrivacyPolicy extends Model {
  resource() {
    return 'pages/privacy'
  }
}
