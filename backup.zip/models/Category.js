import Model from '@/models/Model'

export default class Category extends Model {
  resource() {
    return 'categories'
  }
}
