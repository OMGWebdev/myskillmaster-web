import Model from '@/models/Model'

export default class Subscription extends Model {
  resource() {
    return 'subscription'
  }
}
