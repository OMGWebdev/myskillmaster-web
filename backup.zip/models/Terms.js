import Model from '@/models/Model'

export default class Terms extends Model {
  resource() {
    return 'pages/terms_of_service'
  }
}
